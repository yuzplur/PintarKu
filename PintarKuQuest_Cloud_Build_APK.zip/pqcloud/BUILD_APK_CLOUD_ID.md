PintarKu Quest — build APK otomatis di GitHub Actions

Paket ini berisi proyek Android WebView dan workflow untuk membangun APK debug memakai JDK 17, Gradle 8.7, dan Android SDK 35.

Cara memakai dari HP:
1. Buat repository baru di GitHub (misalnya PintarKuQuest-Android).
2. Upload seluruh ISI folder proyek ini ke root repository. Pastikan folder .github/workflows ikut terunggah.
3. Buka tab Actions di repository dan pilih "Build PintarKu Quest APK".
4. Tekan "Run workflow" (atau tunggu workflow berjalan setelah push ke main).
5. Buka hasil run yang sukses dan unduh artifact "PintarKu-Quest-debug-APK".
6. Ekstrak ZIP artifact, lalu instal APK di HP.

Catatan: workflow ini disiapkan tetapi belum dijalankan di GitHub. APK belum dikompilasi atau diuji; build hanya terkonfirmasi setelah workflow sukses.
