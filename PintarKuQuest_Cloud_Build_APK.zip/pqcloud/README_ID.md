# PintarKu Quest — Proyek Android

Proyek ini membungkus file game HTML yang ada ke dalam aplikasi Android berbasis WebView. Game tidak dibangun ulang dari nol.

## Cara membangun dari HP Android
1. Unduh dan ekstrak ZIP proyek ini di HP.
2. Pasang AndroidIDE dari sumber resminya yang kamu percaya, lalu buka folder `PintarKuQuest_Android_Project`.
3. Izinkan AndroidIDE mengunduh Gradle dan komponen Android SDK yang diminta saat proses sinkronisasi.
4. Jalankan **Build / Assemble Debug**.
5. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`. Pasang APK tersebut untuk pengujian.

## Catatan
- Proyek ini adalah sumber aplikasi Android, bukan APK yang sudah dikompilasi.
- Layar dipaksa landscape dan imersif agar sesuai dengan game battle.
- JavaScript dan penyimpanan DOM diaktifkan untuk kebutuhan game.
- Pengujian tombol, timer 30 detik Level 5, bank soal, audio, dan animasi tetap perlu dilakukan di HP setelah APK dibuat.
- Jika build gagal, kirim teks error AndroidIDE secara utuh agar bisa diperbaiki berdasarkan error nyata.
